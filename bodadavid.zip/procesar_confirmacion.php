<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'conexion_bd.php';

header('Content-Type: application/json');

$response = array();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $codigo = $conexion->real_escape_string($_POST['codigo']);
    $nombre = $conexion->real_escape_string($_POST['nombre']);
    $asistencia = $conexion->real_escape_string($_POST['asistencia']);
    $personas_confirmadas = isset($_POST['personas_confirmadas']) ? (int)$_POST['personas_confirmadas'] : 0;

    // Obtener el valor de max_inv para el código proporcionado
    $sql_max_inv = "SELECT max_inv FROM invitados WHERE codigo = '$codigo'";
    $result_max_inv = $conexion->query($sql_max_inv);

    if ($result_max_inv === false) {
        $response['success'] = false;
        $response['error'] = 'Error en la consulta para obtener max_inv: ' . $conexion->error;
        echo json_encode($response);
        exit();
    }

    if ($result_max_inv->num_rows > 0) {
        $row_max_inv = $result_max_inv->fetch_assoc();
        $max_inv = (int)$row_max_inv['max_inv'];

        if ($personas_confirmadas > $max_inv) {
            $response['success'] = false;
            $response['error'] = 'El número de personas confirmadas no puede ser mayor que ' . $max_inv;
            echo json_encode($response);
            exit();
        }
    } else {
        $response['success'] = false;
        $response['error'] = 'Código no encontrado';
        echo json_encode($response);
        exit();
    }

    // Mensajes de depuración
    error_log("Código: $codigo");
    error_log("Nombre: $nombre");
    error_log("Asistencia: $asistencia");
    error_log("Personas Confirmadas: $personas_confirmadas");

    $sql = "UPDATE invitados SET asistira = '$asistencia', personas_confirmadas = $personas_confirmadas WHERE codigo = '$codigo'";

    if ($conexion->query($sql) === TRUE) {
        $response['success'] = true;
    } else {
        $response['success'] = false;
        $response['error'] = "Error al actualizar el registro: " . $conexion->error;
    }
} else {
    $response['success'] = false;
    $response['error'] = "Método de solicitud no permitido";
}

echo json_encode($response);
$conexion->close();
?>
