<?php
require_once 'conexion_bd.php';

// Consulta para obtener los datos donde asistira es igual a 'sí' o 'no'
$sql_confirmados = "SELECT codigo, nombre, asistira, personas_confirmadas FROM invitados WHERE asistira IS NOT NULL";
$result_confirmados = $conexion->query($sql_confirmados);

if ($result_confirmados === false) {
    die("Error en la consulta: " . $conexion->error);
}

// Consulta para obtener los datos donde asistira es NULL
$sql_pendientes = "SELECT codigo, nombre FROM invitados WHERE asistira IS NULL";
$result_pendientes = $conexion->query($sql_pendientes);

if ($result_pendientes === false) {
    die("Error en la consulta: " . $conexion->error);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administración de Invitados</title>
    <!-- Incluyendo Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <!-- Incluyendo SweetAlert CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <style>
        /* Estilos adicionales para el modal */
        .modal {
            display: none; /* Ocultar el modal por defecto */
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.4); /* Filtro oscuro */
        }
        .modal-content {
            background-color: #fefefe;
            margin: 2% auto; /* 15% desde la parte superior y centrado */
            padding: 20px;
            border: 1px solid #888;
            width: 80%; /* Ancho del modal */
            max-width: 600px;
            border-radius: 8px;
        }
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
        /* Media queries para dispositivos con un ancho máximo de 932px */
        @media (max-width: 932px) {
            .my-2 {
                flex-direction: column;
            }
            .my-2 > div {
                margin-bottom: 10px;
            }
            .ml-4 {
                margin-left: 0 !important;
            }
            .tablex {
                width: 100%;
            }
        }
    </style>
</head>
<body class="bg-gray-100 font-sans leading-normal tracking-normal">

    <div class="container mx-auto px-4 sm:px-8">
        <div class="py-8">
            <div>
                <h2 class="text-2xl font-semibold leading-tight">Invitados Confirmados</h2>
            </div>
            <div class="my-2 flex sm:flex-row flex-col">
                <div class="block relative">
                    <span class="h-full absolute inset-y-0 left-0 flex items-center pl-2">
                        <svg viewBox="0 0 24 24" class="h-4 w-4 fill-current text-gray-500">
                            <path d="M10,17c-3.9,0-7-3.1-7-7s3.1-7,7-7s7,3.1,7,7S13.9,17,10,17z M10,5C7.2,5,5,7.2,5,10s2.2,5,5,5s5-2.2,5-5S12.8,5,10,5z M20.7,20.3l-5.6-5.6c1.2-1.4,1.9-3.2,1.9-5.2c0-4.4-3.6-8-8-8S1,4.4,1,8.9s3.6,8,8,8c1.9,0,3.8-0.7,5.2-1.9l5.6,5.6c0.4,0.4,1,0.4,1.4,0C21.1,21.3,21.1,20.7,20.7,20.3z"></path>
                        </svg>
                    </span>
                    <input id="searchInput" placeholder="Buscar" class="appearance-none rounded-r rounded-l sm:rounded-l-none border border-gray-400 border-b block pl-8 pr-6 py-2 w-full bg-white text-sm placeholder-gray-400 text-gray-700 focus:bg-white focus:placeholder-gray-600 focus:text-gray-700 focus:outline-none" onkeyup="filterTable()" />
                </div>
                <div class="relative ml-4">
                    <select id="filterAsistencia" class="appearance-none border border-gray-400 border-b block pl-2 pr-6 py-2 w-full bg-white text-sm placeholder-gray-400 text-gray-700 focus:bg-white focus:placeholder-gray-600 focus:text-gray-700 focus:outline-none" onchange="filterTable()">
                        <option value="">Todos</option>
                        <option value="sí">Asistirán</option>
                        <option value="no">No asistirán</option>
                    </select>
                </div>
                <div class="ml-4">
                    <button onclick="showPendientes()" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                        Invitados Pendientes
                    </button>
                </div>
    </div>

            <div class="tablex">
            <div class="overflow-x-auto">
                <div class="min-w-full shadow rounded-lg overflow-hidden">
                    <table id="dataTable" class="min-w-full leading-normal">
                        <thead>
                            <tr>
                                <th class="px-3 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                                    Código
                                </th>
                                <th class="px-3 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                                    Nombre
                                </th>
                                <th class="px-3 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                                    Asistirá
                                </th>
                                <th class="px-3 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                                    #Inv
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $result_confirmados->fetch_assoc()) { ?>
                            <tr data-asistencia="<?php echo htmlspecialchars($row['asistira']); ?>">
                                <td class="px-3 py-5 border-b border-gray-200 bg-white text-sm">
                                    <p class="text-gray-900 whitespace-no-wrap"><?php echo htmlspecialchars($row['codigo']); ?></p>
                                </td>
                                <td class="px-3 py-5 border-b border-gray-200 bg-white text-sm">
                                    <p class="text-gray-900 whitespace-no-wrap"><?php echo htmlspecialchars($row['nombre']); ?></p>
                                </td>
                                <td class="px-3 py-5 border-b border-gray-200 bg-white text-sm">
                                    <p class="text-gray-900 whitespace-no-wrap"><?php echo htmlspecialchars($row['asistira']); ?></p>
                                </td>
                                <td class="px-3 py-5 border-b border-gray-200 bg-white text-sm">
                                    <p class="text-gray-900 whitespace-no-wrap"><?php echo htmlspecialchars($row['personas_confirmadas']); ?></p>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
            </div>
        </div>
    </div>

    <!-- Modal para invitados pendientes -->
    <div id="modalPendientes" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closePendientes()">&times;</span>
            <h2 class="text-2xl font-semibold leading-tight mb-4">Invitados Pendientes</h2>
            <table class="min-w-full leading-normal">
                <thead>
                    <tr>
                        <th class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                            Código
                        </th>
                        <th class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                            Nombre
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result_pendientes->fetch_assoc()) { ?>
                    <tr>
                        <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                            <p class="text-gray-900 whitespace-no-wrap"><?php echo htmlspecialchars($row['codigo']); ?></p>
                        </td>
                        <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                            <p class="text-gray-900 whitespace-no-wrap"><?php echo htmlspecialchars($row['nombre']); ?></p>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        function filterTable() {
            let input = document.getElementById('searchInput');
            let filter = input.value.toLowerCase();
            let select = document.getElementById('filterAsistencia');
            let filterAsistencia = select.value.toLowerCase();
            let table = document.getElementById('dataTable');
            let tr = table.getElementsByTagName('tr');

            for (let i = 1; i < tr.length; i++) {
                let tdCode = tr[i].getElementsByTagName('td')[0];
                let tdName = tr[i].getElementsByTagName('td')[1];
                let asistencia = tr[i].getAttribute('data-asistencia');
                if (tdCode || tdName) {
                    let codeValue = tdCode.textContent || tdCode.innerText;
                    let nameValue = tdName.textContent || tdName.innerText;
                    if (
                        (codeValue.toLowerCase().indexOf(filter) > -1 || nameValue.toLowerCase().indexOf(filter) > -1) &&
                        (filterAsistencia === "" || asistencia.toLowerCase() === filterAsistencia)
                    ) {
                        tr[i].style.display = "";
                    } else {
                        tr[i].style.display = "none";
                    }
                }
            }
        }

        function showPendientes() {
            document.getElementById('modalPendientes').style.display = "block";
        }

        function closePendientes() {
            document.getElementById('modalPendientes').style.display = "none";
        }
    </script>

</body>
</html>

<?php
$conexion->close();
?>
