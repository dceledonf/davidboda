<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'conexion_bd.php';

header('Content-Type: application/json');

$response = array();

if (isset($_GET['codigo'])) {
    $codigo = $conexion->real_escape_string($_GET['codigo']);
    $sql = "SELECT nombre, max_inv FROM invitados WHERE codigo = '$codigo'";
    $result = $conexion->query($sql);

    if ($result === false) {
        $response['error'] = 'Error en la consulta: ' . $conexion->error;
        echo json_encode($response);
        exit();
    }

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $response = ['exists' => true, 'nombre' => $row['nombre'], 'max_inv' => $row['max_inv']];
    } else {
        $response = ['exists' => false];
    }
} else {
    $response = ['exists' => false, 'error' => 'Código no proporcionado'];
}

echo json_encode($response);
$conexion->close();
?>
