<?php
$servername = 'localhost';
$username = 'id22163315_root';
$password = 'Tornillo1!';
$dbname = 'id22163315_bodavd';

$conexion = new mysqli($servername, $username, $password, $dbname);

if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}

// No cierres la conexión aquí. Solo se establece.
?>
