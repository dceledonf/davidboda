<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmación de Asistencia</title>
    <!-- Incluyendo Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <!-- Incluyendo SweetAlert CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <!-- Incluyendo Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;700&display=swap" rel="stylesheet">
    <!-- Incluyendo FontAwesome para los iconos -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        .step {
            display: none;
        }
        .step.active {
            display: block;
        }
        .background-image {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('wallpaper.jpg');
            background-size: cover;
            background-position: center;
            z-index: -2;
        }
        .overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5); /* Filtro oscuro */
            z-index: -1;
        }
        body, .navbar, .navbar a {
            font-family: 'Cinzel', serif;
            overflow:hidden;
        }
        .navbar {
            height: 10vh;
            margin-top: -8px;
        }
        .navbar img {
            width: 2.47vw;
            height: auto;
            margin-left: 1.2%;
        }
        .main-content {
            height: 90vh;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10;
        }
        #progress-bar {
            background-color: #E1C699;
        }
        .custom-button {
            background-color: #E1C699;
        }
        .custom-button:hover {
            background-color: #d1b388; /* Un tono más oscuro para el efecto hover */
        }
        .hidden {
            display: none;
        }
        /* Estilos para la segunda barra de navegación */
        .navbar-second {
            display: none;
        }
        @media (max-width: 932px) {
            .navbar {
                display: none;
            }
            .navbar-second {
                display: flex;
                justify-content: space-between;
                align-items: center;
                background-color: transparent;
                padding: 10px;
                color: white;
                position: fixed;
                top: 0;
                width: 100%;
                z-index: 30;
            }
            .navbar-second a {
                color: white;
                text-decoration: none;
                margin: 0 10px;
            }
            .navbar-second img {
                width: 50px;
                height: auto;
            }
            .main-content {
                height: 90vh;
                display: flex;
                align-items: center;
                justify-content: center;
                z-index: 10;
                max-width: 90%;
                margin-left: 1rem;
            }
        }
    </style>
</head>
<body class="bg-gray-100 font-sans">
    <!-- Fondo y filtro oscuro -->
    <div class="background-image"></div>
    <div class="overlay"></div>
    
    <!-- Navegación superior -->
    <header class="absolute top-0 left-0 w-full z-30 bg-transparent">
        <nav class="container mx-auto p-6 flex justify-between items-center navbar">
            <div class="flex items-center text-3xl font-semibold text-white">
                <a href="https://www.google.com"><img src="logodavid.png" alt="Logo" class="h-8 inline"></a>
                <span class="ml-4 whitespace-nowrap text-lg font-thin">Valeria & David</span>
            </div>
            <div class="flex space-x-6 text-white items-center">
                <a href="#" class="hover:text-gray-300 font-bold">Página Principal</a>
                <a href="#" class="hover:text-gray-300">Hospedaje</a>
                <a href="#" class="hover:text-gray-300"><i class="fas fa-search hidden"></i></a>
            </div>
        </nav>
        <nav class="navbar-second">
            <a href="#"><img src="logodavid.png" alt="Logo"></a>
        </nav>
    </header>

    <!-- Formulario de confirmación de asistencia -->
    <div class="main-content relative z-30">
        <div class="max-w-md mx-auto bg-white p-8 rounded-lg shadow-lg">
            <h1 class="text-2xl font-bold text-center mb-6 text-gray-800">Confirmación de Asistencia</h1>
            <div class="relative pt-1">
                <div class="overflow-hidden h-2 mb-4 text-xs flex rounded bg-gray-200">
                    <div id="progress-bar" class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-500" style="width: 0;"></div>
                </div>
                <div class="text-right text-gray-600 text-sm mb-4" id="step-indicator">Paso 1 de 4</div>
            </div>
            <form id="multiStepForm" action="procesar_confirmacion.php" method="post">
                <input type="hidden" id="personas_confirmadas" name="personas_confirmadas" value="0">
                <div class="step active">
                    <div class="mb-4">
                        <label for="codigo" class="block text-gray-700">Código:</label>
                        <input type="text" id="codigo" name="codigo" class="mt-1 p-2 w-full border rounded-md" required>
                    </div>
                    <button type="button" class="w-full ml-2 text-white p-2 rounded-md custom-button" onclick="checkCodigo()">Siguiente</button>
                </div>
                <div class="step">
                    <div class="mb-4">
                        <label for="nombre" class="block text-gray-700">Nombre:</label>
                        <input type="text" id="nombre" name="nombre" class="mt-1 p-2 w-full border rounded-md" readonly required>
                    </div>
                    <div class="flex justify-between">
                        <button type="button" class="w-full mr-2 bg-gray-400 text-white p-2 rounded-md hover:bg-gray-600" onclick="prevStep()">Atrás</button>
                        <button type="button" class="w-full ml-2 text-white p-2 rounded-md custom-button" onclick="nextStep()">Siguiente</button>
                    </div>
                </div>
                <div class="step">
                    <div class="mb-4">
                        <label for="asistencia" class="block text-gray-700">¿Asistirá?</label>
                        <select id="asistencia" name="asistencia" class="mt-1 p-2 w-full border rounded-md" required onchange="checkAsistencia()">
                            <option value="">Seleccione una opción</option>
                            <option value="sí">Sí</option>
                            <option value="no">No</option>
                        </select>
                    </div>
                    <div class="flex justify-between" id="asistencia-buttons">
                        <button type="button" class="w-full mr-2 bg-gray-400 text-white p-2 rounded-md hover:bg-gray-600" onclick="prevStep()">Atrás</button>
                        <button type="button" class="w-full ml-2 text-white p-2 rounded-md custom-button" onclick="nextStep()">Siguiente</button>
                    </div>
                </div>
                <div class="step" id="numero-personas-step">
                    <div class="mb-4">
                        <label for="numero_personas" class="block text-gray-700">Número de personas (incluyéndote a ti):</label>
                        <input type="number" id="numero_personas" name="personas_confirmadas" min="1" class="mt-1 p-2 w-full border rounded-md" required>
                    </div>
                    <div class="flex justify-between">
                        <button type="button" class="w-full mr-2 bg-gray-400 text-white p-2 rounded-md hover:bg-gray-600" onclick="prevStep()">Atrás</button>
                        <button type="button" class="w-full ml-2 text-white p-2 rounded-md custom-button" onclick="submitConfirmacion()">Enviar Confirmación</button>
                    </div>
                </div>
                <div class="step" id="confirmacion-final-step">
                    <div class="mb-4">
                        <p class="text-gray-700">Gracias por confirmar que no asistirás. Si deseas cambiar tu decisión, puedes volver atrás.</p>
                    </div>
                    <div class="flex justify-between">
                        <button type="button" class="w-full mr-2 bg-gray-400 text-white p-2 rounded-md hover:bg-gray-600" onclick="prevStep()">Atrás</button>
                        <button type="button" class="w-full ml-2 text-white p-2 rounded-md custom-button" onclick="submitNoAsistencia()">Confirmar No Asistencia</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <!-- Incluyendo SweetAlert JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>
    <!-- Script para el formulario multipaso -->
    <script>
        let currentStep = 0;
        let previousStep = -1;
        const progressBar = document.getElementById('progress-bar');
        const stepIndicator = document.getElementById('step-indicator');
        let maxInv = 0;

        function updateProgressBar() {
            const steps = document.querySelectorAll('.step');
            const progress = (currentStep / (steps.length - 1)) * 100;
            progressBar.style.width = `${progress}%`;
            stepIndicator.textContent = `Paso ${currentStep + 1} de ${steps.length}`;
        }

        function nextStep() {
            const steps = document.querySelectorAll('.step');
            const currentInputs = steps[currentStep].querySelectorAll('input, select');
            for (const input of currentInputs) {
                if (!input.checkValidity()) {
                    input.reportValidity();
                    return;
                }
            }
            steps[currentStep].classList.remove('active');
            previousStep = currentStep;
            currentStep = (currentStep + 1) % steps.length;
            steps[currentStep].classList.add('active');
            updateProgressBar();
        }

        function prevStep() {
            const steps = document.querySelectorAll('.step');
            steps[currentStep].classList.remove('active');
            if (previousStep !== -1) {
                currentStep = previousStep;
            } else {
                currentStep = (currentStep - 1 + steps.length) % steps.length;
            }
            previousStep = -1;
            steps[currentStep].classList.add('active');
            updateProgressBar();
        }

        function checkAsistencia() {
            const asistencia = document.getElementById('asistencia').value;
            const steps = document.querySelectorAll('.step');
            if (asistencia === 'no') {
                steps[currentStep].classList.remove('active');
                previousStep = currentStep;
                currentStep = steps.length - 1; // Ir directamente al paso de confirmación final
                steps[currentStep].classList.add('active');
                document.getElementById('personas_confirmadas').value = '0'; // Asegurarse de que personas_confirmadas sea 0
            } else {
                steps[currentStep].classList.remove('active');
                previousStep = currentStep;
                currentStep = steps.length - 2; // Ir al siguiente paso (número de personas)
                steps[currentStep].classList.add('active');
            }
            updateProgressBar();
        }

        function checkCodigo() {
            const codigo = document.getElementById('codigo').value;
            fetch(`verificar_codigo.php?codigo=${codigo}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    console.log(data); // Agregar mensaje de consola para depuración
                    if (data.exists) {
                        document.getElementById('nombre').value = data.nombre;
                        document.getElementById('numero_personas').max = data.max_inv;
                        maxInv = data.max_inv;
                        nextStep();
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Código no válido',
                            text: 'El código de invitación no existe.',
                            confirmButtonText: 'OK'
                        });
                    }
                })
                .catch(error => {
                    console.error('Error al verificar el código:', error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Hubo un error al verificar el código. Por favor, inténtalo de nuevo.',
                        confirmButtonText: 'OK'
                    });
                });
        }

        function submitConfirmacion() {
            const codigo = document.getElementById('codigo').value;
            const nombre = document.getElementById('nombre').value;
            const asistencia = document.getElementById('asistencia').value;
            const personasConfirmadas = document.getElementById('numero_personas').value;

            const formData = new FormData();
            formData.append('codigo', codigo);
            formData.append('nombre', nombre);
            formData.append('asistencia', asistencia);
            formData.append('personas_confirmadas', personasConfirmadas);

            fetch('procesar_confirmacion.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Confirmación recibida',
                        text: 'Gracias por confirmar tu asistencia.',
                        confirmButtonText: 'OK'
                    }).then(() => {
                        window.location.href = 'index.php';
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: data.error || 'Hubo un error al enviar tu confirmación. Por favor, inténtalo de nuevo.',
                        confirmButtonText: 'OK'
                    });
                }
            })
            .catch(error => {
                console.error('Error al enviar la confirmación:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Hubo un error al enviar tu confirmación. Por favor, inténtalo de nuevo.',
                    confirmButtonText: 'OK'
                });
            });
        }

        function submitNoAsistencia() {
            const codigo = document.getElementById('codigo').value;
            const nombre = document.getElementById('nombre').value;

            const formData = new FormData();
            formData.append('codigo', codigo);
            formData.append('nombre', nombre);
            formData.append('asistencia', 'no');
            formData.append('personas_confirmadas', '0');

            fetch('procesar_confirmacion.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Confirmación recibida',
                        text: 'Gracias por confirmar que no asistirás.',
                        confirmButtonText: 'OK'
                    }).then(() => {
                        window.location.href = 'index.php';
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Hubo un error al enviar tu confirmación. Por favor, inténtalo de nuevo.',
                        confirmButtonText: 'OK'
                    });
                }
            })
            .catch(error => {
                console.error('Error al enviar la confirmación:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Hubo un error al enviar tu confirmación. Por favor, inténtalo de nuevo.',
                    confirmButtonText: 'OK'
                });
            });
        }

        // Ajustar el desplazamiento cuando se enfoca en un campo de entrada
        document.querySelectorAll('input, select').forEach(input => {
            input.addEventListener('focus', () => {
                setTimeout(() => {
                    input.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }, 300); // Un pequeño retraso para asegurarse de que el teclado esté completamente visible
            });
        });

        document.addEventListener('DOMContentLoaded', () => {
            updateProgressBar();

            const urlParams = new URLSearchParams(window.location.search);
            const status = urlParams.get('status');

            if (status === 'success') {
                Swal.fire({
                    icon: 'success',
                    title: 'Confirmación recibida',
                    text: '¡Gracias por confirmar tu asistencia!',
                    confirmButtonText: 'OK'
                }).then(() => {
                    window.location.href = 'index.php';
                });
            } else if (status === 'error') {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Hubo un error al procesar tu confirmación. Por favor, inténtalo de nuevo.',
                    confirmButtonText: 'OK'
                }).then(() => {
                    window.location.href = 'index.php';
                });
            }
        });
    </script>
</body>
</html>
